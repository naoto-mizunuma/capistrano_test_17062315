# capistrano_test_17062315
**capistranoのローカルからローカルへのデプロイテスト**
* その1-17062615
